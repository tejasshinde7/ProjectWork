package com.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Admin {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
@Column(name = "adId",length = 20)
private int aid;
@Column(name = "adEmail",length = 30)
private String aemail;
@Column(name = "adPass",length = 20)
private String apass;
}
