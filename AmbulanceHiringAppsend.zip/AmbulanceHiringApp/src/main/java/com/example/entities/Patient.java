package com.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Patient {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private int pid;
@Column(length = 20)
private String pname;
@Column(length = 20)
private String pemail;
@Column(length = 20)
private long pmobno;
@Column(length = 10)
private String pgender;
@Column(length = 30)
private String paddress;

}
