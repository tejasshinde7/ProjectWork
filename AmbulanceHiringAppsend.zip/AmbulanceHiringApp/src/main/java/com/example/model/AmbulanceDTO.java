package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AmbulanceDTO {
	private int emsno;
	private String ownername;
	private String atype;
	private int rcno;
}
