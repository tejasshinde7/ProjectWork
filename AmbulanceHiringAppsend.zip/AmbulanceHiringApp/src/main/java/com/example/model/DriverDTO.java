package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DriverDTO {
	private int did;
	private String dname;
	private long mobno;
}
