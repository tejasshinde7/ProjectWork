package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class PatientDTO {
	private int pid;
	private String pname;
	private String pemail;
	private long pmobno;
	private String pgender;
	private String paddress;
}
