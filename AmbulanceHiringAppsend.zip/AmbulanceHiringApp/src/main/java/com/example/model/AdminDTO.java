package com.example.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AdminDTO {
	private int aid;
	private String aemail;
	private String apass;
}
