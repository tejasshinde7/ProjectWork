package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Driver;
import com.example.entities.Patient;
import com.example.model.PatientDTO;
import com.example.service.PatientService;
import com.example.utitity.Converter;

@RestController
@RequestMapping("/patient")
public class PatientController {
@Autowired
private PatientService patientService;
@Autowired
Converter converter;
@PostMapping("/add")
ResponseEntity<PatientDTO> add(@RequestBody PatientDTO patientDTO) {
	final Patient patient=converter.convertToPatientEntity(patientDTO);
	return new ResponseEntity<PatientDTO>(patientService.savePatientInfo(patient),HttpStatus.CREATED);
}
@GetMapping("/getAll")
public List<PatientDTO> getAllPatientInfo(){
	
	return patientService.getAllPatientInfo();
}
@GetMapping("/getByPatientrId/{pId}")
public PatientDTO getByPatientId(@PathVariable("pId")  int pid) {
	
	
	return patientService.getByPatientId(pid);
}

@DeleteMapping("/deletePatientById/{dId}")
public String deletePatientById(@PathVariable("pId")  int pid ) {
	// TODO Auto-generated method stub
	return patientService.deletePatientInfoById(pid);
}

@PutMapping("/updatePatient/{emsNo}")
public PatientDTO updatePatient( @PathVariable("pId") int pid,@RequestBody Patient patient) {
	// TODO Auto-generated method stub
   return patientService.updatePatientInfo(pid, patient);
}
}
