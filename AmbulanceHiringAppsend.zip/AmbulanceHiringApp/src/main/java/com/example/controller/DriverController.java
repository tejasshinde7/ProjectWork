package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.entities.Ambulance;
import com.example.entities.Driver;
import com.example.model.DriverDTO;
import com.example.service.AmbulanceService;
import com.example.service.DriverService;
import com.example.utitity.Converter;
@RestController
@RequestMapping("/driver")
public class DriverController {
	@Autowired
private DriverService driverService;
	@Autowired
	Converter converter;
	@PostMapping("/add")
	ResponseEntity<DriverDTO> add(@RequestBody DriverDTO driverDTO) {
	final Driver driver=converter.convertToDriverEntity(driverDTO);
	return new ResponseEntity<DriverDTO>(driverService.saveDriverInfo(driver),HttpStatus.CREATED);
		
	
	}
	@GetMapping("/getAll")
	public List<DriverDTO> getAllDriverInfo(){
		
		return driverService.getAllDriverInfo();
	}
	@GetMapping("/getByDriverId/{dId}")
	public DriverDTO getByDriverId(@PathVariable("dId")  int did) {
		
		
		return driverService.getByDriverId(did);
	}

	@DeleteMapping("/deleteDriverById/{dId}")
	public String deleteDriverById(@PathVariable("dId")  int did ) {
		// TODO Auto-generated method stub
		return driverService.deleteDriverInfoById(did);
	}

   @PutMapping("/updateDriver/{emsNo}")
	public DriverDTO updateDriver( @PathVariable("dId") int did,@RequestBody Driver driver) {
		// TODO Auto-generated method stub
	   return driverService.updateDriverInfo(did, driver);
	}
}
