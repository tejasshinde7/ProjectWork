package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.entities.Ambulance;
import com.example.model.AmbulanceDTO;
import com.example.repository.AmbulanceRepository;
import com.example.service.AmbulanceService;
import com.example.utitity.Converter;
@Service
public class AmbulanceServiceImpl implements AmbulanceService{
	@Autowired
private AmbulanceRepository ambulanceRepository;
	@Autowired
	Converter converter;
	@Override
	public AmbulanceDTO saveAmbulanceInfo(Ambulance ambulance) {
		// TODO Auto-generated method stub
		Ambulance aa= ambulanceRepository.save(ambulance);
		return converter.convertToAmbulanceDTO(aa);
	}

	@Override
	public List<AmbulanceDTO> geAllAmbulanceInfo() {
		// TODO Auto-generated method stub
		List<Ambulance> aa=ambulanceRepository.findAll();
		List<AmbulanceDTO> dtoaa=new ArrayList<>();
		for(Ambulance a :aa) {
			dtoaa.add(converter.convertToAmbulanceDTO(a));
		}
		return dtoaa;
	}

	@Override
	public AmbulanceDTO getByAmbulanceId(int emsno) {
		// TODO Auto-generated method stub
		Ambulance aa= ambulanceRepository.findById(emsno).get();
		return converter.convertToAmbulanceDTO(aa);
	}

	@Override
	public String deleteAmbulanceInfoById(int emsno ) {
		// TODO Auto-generated method stub
		ambulanceRepository.deleteById(emsno);
		return "Ambulance Info deleted";
	}

	@Override
	public AmbulanceDTO updateAmbulanceInfo(int emsno, Ambulance ambulance) {
		// TODO Auto-generated method stub
		Ambulance aa=ambulanceRepository.findById(emsno).get();
	aa.setOwnername(ambulance.getOwnername());
	aa.setAtype(ambulance.getAtype());
	aa.setRcno(ambulance.getRcno());
		Ambulance aaa=ambulanceRepository.save(aa);
		return converter.convertToAmbulanceDTO(aaa);
	}
	

}
