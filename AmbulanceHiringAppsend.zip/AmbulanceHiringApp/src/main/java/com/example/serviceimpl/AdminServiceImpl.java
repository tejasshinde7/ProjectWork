package com.example.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entities.Admin;
import com.example.model.AdminDTO;
import com.example.repository.AdminRepository;
import com.example.service.AdminService;
import com.example.utitity.Converter;
@Service
public class AdminServiceImpl implements AdminService{
	@Autowired
public AdminRepository adminRepository;
	@Autowired
	Converter converter;
	@Override
	public AdminDTO saveAdminInfo(Admin admin) {
		// TODO Auto-generated method stub
		Admin adm= adminRepository.save(admin);
		return converter.convertToAdminDTO(adm);
	}

	@Override
	public List<AdminDTO> getAllAdminInfo() {
		// TODO Auto-generated method stub
		List<Admin> admins= adminRepository.findAll();
		List<AdminDTO> dtoa=new ArrayList<>();
	for(Admin a:admins) {
		dtoa.add(converter.convertToAdminDTO(a));
	}
	return dtoa;
	}

	@Override
	public AdminDTO  getByAdminId( int aid) {
		// TODO Auto-generated method stub
		Admin a= adminRepository.findById(aid).get();
		return converter.convertToAdminDTO(a);
	}

	@Override
	public String deleteAdminInfoById(int aid) {
		// TODO Auto-generated method stub
		adminRepository.deleteById(aid);
		return "Admin deleted";
	}

	@Override
	public AdminDTO  updateAdminInfo(int aid, Admin admin) {
		// TODO Auto-generated method stub
		Admin aa=adminRepository.findById(aid).get();
		aa.setAemail(admin.getAemail());
		aa.setApass(admin.getApass());
		Admin ad=adminRepository.save(aa);
		return converter.convertToAdminDTO(ad);
	}

}
